//inlcusions:
#include "dtekv-lib.h"
#include "led_ws218.h"
#define FPS 24
#define NUM_LEDS 125
extern void enable_interrupts( void );

//implicit declarations:
void handle_interrupt(unsigned int cause); 
void poll_buttons();
void snake_upd();
void spawn_berry();
void init();
void timer_init();
char snake_check();
void snake_init();
int rand();
void gpio_init();

//structs:
typedef struct {
    int x;
    int y;
    int z;
} pos;

//global variables:
volatile int timeoutcount;
volatile color cube[5][5][5];
pos snake[125];
int snake_len;
int highscore = 0;
pos berry;
char direction;
char old_direction;
unsigned int seed;
int score;
volatile int reset_flag;

//how to define colors:  (the struct is defined in led_ws218.h file) 
color white= {1,1,1};
color black={0,0,0};
color snake_color={20,20,0};
color berry_color={50,0,0};
color head_color = {0,70,0};

color snake_body[6] = {{40,40,0}, {25,25,0}, {17,17,0}, {8,8,0}, {4,4,0}, {1,1,0},};

//functions:

void handle_interrupt(unsigned int cause){
    if(cause == 16){
    volatile int* TMR1_flag = (volatile int*) 0x04000020;
    volatile int* TMR1_CTRL = (volatile int*) 0x04000024; //for starting and stopping timer

    timeoutcount++;
    colour_it(cube);  //this should return the timer exactly the same

    TMR1_flag[0] = 0;
    TMR1_CTRL[0] = 0x5;  //start the timer back up again
    }
    else{
        print("unidentified interrupt \n");
    }
        return;
    
}

void poll_buttons(){
   volatile int* gpio1_data = (volatile int*)0x040000E0;
   int data = (*(gpio1_data) & 0xFF) >> 1;
//   print_dec(data);
  // print("\n");


    switch (data){
        case 127-1:
            if(old_direction != 'd')
                direction = 'u';
            break;
        case 127-2:
            if(old_direction != 'u')
                direction = 'd';
            break;
        case 127-4:            
            if(old_direction != 'l')
                direction = 'r';
            break;
        case 127-8:            
            if(old_direction != 'r')
                direction = 'l';
            break;
        case 127-16:
            if(old_direction != 'b')
                direction = 'f';
            break;
        case 127-32:
            if(old_direction != 'f')
                direction = 'b';
            break;
        case 127-64:
            //print("aaa");
            reset_flag = 1;
            break;
        default:
            direction = direction;
            break;
    };
    
  //  tab[0] = direction;
   // print(tab);
    
    //this has to change smth called dir, if the button pressed is directly opposite to dir, then discard it
    //I put this here, as snake upd does moveent, so it cannot discard, so this will validate, that there is only one button pressed, and that it is
    //one that is valid, not in the exact opposite direction of moving
    return;
}

void snake_upd(){
    pos head = snake[0];
    //figure out new head position
    switch (direction){
        case 'u':
            head.z++;
            if(head.z > 4)
                head.z = 0;
            break;
        case 'd':
            head.z--;
            if(head.z < 0)
                head.z = 4;
            break;

        case 'r':
            head.y++;
            if(head.y > 4)
                head.y = 0;
            break;
        case 'l':
            head.y--;
            if(head.y < 0)
                head.y = 4;
            break;

        case 'f':
            head.x++;
            if(head.x > 4)
                head.x = 0;
            break;
        case 'b':
            head.x--;
            if(head.x < 0)
                head.x = 4;
            break;
    };
    old_direction = direction;


    //make it just longer,we can shorten it down after we check for berry
    for(int i = snake_len; i > 0; i--)
        snake[i] = snake[i-1];
    snake[0] = head;

    // add gradient to the body
    for(int i = 1; i < snake_len; i++){
        color gradient = {};
        gradient.red = snake_body[i%5].red;
        gradient.green = snake_body[i%5].green;
        gradient.blue = snake_body[i%5].blue;

        cube[snake[i].x][snake[i].y][snake[i].z] = gradient;
    }

    cube[head.x][head.y][head.z] = head_color;

  /*  for(int i = 0; i <= snake_len; i++){
        print_dec(snake[i].x);
        print(" ");
        print_dec(snake[i].y);
        print(" ");
        print_dec(snake[i].z);
        print("\n");
    }*/
  //  print("\n");
    
    if((head.x == berry.x)&&(head.y == berry.y)&&(head.z == berry.z)){
        snake_len++;           //increase snake length
        spawn_berry();  //create a new one I assume this lights it up
        score++;
        print("score: ");
        print_dec(score);
        print("\n");
    }
    else if(snake_check()){
        cube[snake[snake_len].x][snake[snake_len].y][snake[snake_len].z] = white;  //turn of the led for tail
        snake[snake_len] = (pos){0,0,0};  //zero it to be explicit
        cube[head.x][head.y][head.z] = head_color;  //do it again
        
    }
    return;
}
void spawn_berry(){
    int cross_out[125];
    for(int i = 0; i < 125; i++)
        cross_out[i] = 0;

    for(int i = 0; i < snake_len; i++){
        cross_out[snake[i].x*25+5*snake[i].y+snake[i].z] = 1;
       // print_dec(cross_out[snake[i].x*25+5*snake[i].y+snake[i].z]);
    }
        

    int random_number = 1 + (rand() % ( 125-snake_len) ) ;  //this is how many zeros we want to see
    int p = 0;   //this is the position of berry after
  //  print_dec(random_number);
    //print(" ");
    //print_dec(p);
    //print("\n");
    while(random_number>0){
        random_number -= (1-cross_out[p]);
        p++;
    }
    p--;   //correct cuz we add always

   // print_dec(random_number);
    //print(" ");
    //print_dec(p);
    //print("\n");

    berry.x = p/25;
    p %= 25;
    berry.y = p/5;
    p %= 5;
    berry.z = p;

    cube[berry.x][berry.y][berry.z] = berry_color;
    
    return;
}
char snake_check(){
    for(int i = 1; i < snake_len; i++){
        if((snake[0].x == snake[i].x) && (snake[0].y == snake[i].y) && (snake[0].z == snake[i].z))
            return 0;
    }
    return 1;
}








void init(){
    for(int i = 0; i < 5; i++){
        for(int j = 0; j < 5; j++){
            for(int k = 0; k < 5; k++){
                cube[i][j][k] = white;
            }
        }
    }
    timeoutcount = 0;
    direction = 'f';
    old_direction = 'r';
    score = 0;
    reset_flag = 0;

    init_led();
    snake_init();
    timer_init();
    enable_interrupts();
    gpio_init();

    //seed randomness in switches
    volatile int* switches = (volatile int*) 0x04000010 ;
    seed = (*switches);

    
    return;
}

void snake_init(){
    //head is at 0, for easier code later
    snake_len = 5;
    snake[4] = (pos){0, 0, 0};
    snake[3] = (pos){0, 1, 0};
    snake[2] = (pos){0, 2, 0};
    snake[1] = (pos){0, 3, 0};
    snake[0] = (pos){0, 4, 0};
    //already light the leds so it cna stand for a sec
    cube[0][0][0] = snake_color;
    cube[0][1][0] = snake_color;
    cube[0][2][0] = snake_color;
    cube[0][3][0] = snake_color;
    cube[0][4][0] = head_color;

    berry = (pos){3,4,0};
    cube[berry.x][berry.y][berry.z] = berry_color;

}

void timer_init(){
  volatile int* TMR1_PLow = (volatile int*) 0x04000028;
  volatile int* TMR1_PHigh = (volatile int*) 0x0400002C;
  int timeout = (30000000 / FPS) - 1;
  TMR1_PLow[0] = timeout & 0xFFFF;
  TMR1_PHigh[0] = (timeout >> 16) & 0xFFFF;

  volatile int* TMR1_CTRL = (volatile int*) 0x04000024; //for starting and stopping timer
  TMR1_CTRL[0] = 0x5;  //start the timer, generating interrupts

  return;
}


void gpio_init(){
    volatile int* gpio1_dir = (volatile int*) 0x040000E4;
    *gpio1_dir = (*gpio1_dir) & 0xFFFFFF81;
    *gpio1_dir = (*gpio1_dir) | 0x1;

    volatile int* gpio1_data = (volatile int*) 0x040000E0;

    *gpio1_data = ((*gpio1_data) | 0x1);



    return;   
}


int main(){
/*unsigned int mcycle, minstret, mhpmcounter3, mhpmcounter4, mhpmcounter5, mhpmcounter6, mhpmcounter7, mhpmcounter8, mhpmcounter9;
asm volatile ("csrw mcycle, x0");
asm volatile ("csrw minstret, x0");
asm volatile ("csrw mhpmcounter3, x0");
asm volatile ("csrw mhpmcounter4, x0");
asm volatile ("csrw mhpmcounter5, x0");
asm volatile ("csrw mhpmcounter6, x0");
asm volatile ("csrw mhpmcounter7, x0");
asm volatile ("csrw mhpmcounter8, x0");
asm volatile ("csrw mhpmcounter9, x0");*/
start:
  /*  asm("csrr %0, mcycle" : "=r"(mcycle));
    asm("csrr %0, minstret" : "=r"(minstret));
    asm("csrr %0, mhpmcounter3" : "=r"(mhpmcounter3));
    asm("csrr %0, mhpmcounter4" : "=r"(mhpmcounter4));
    asm("csrr %0, mhpmcounter5" : "=r"(mhpmcounter5));
    asm("csrr %0, mhpmcounter6" : "=r"(mhpmcounter6));
    asm("csrr %0, mhpmcounter7" : "=r"(mhpmcounter7));
    asm("csrr %0, mhpmcounter8" : "=r"(mhpmcounter8));
    asm("csrr %0, mhpmcounter9" : "=r"(mhpmcounter9));
    print("\nThe indicators are as follows:\n");
    print("mcycle: ");
    print_dec(mcycle);
    print("\n");
    print("minstret: ");
    print_dec(minstret);
    print("\n");
    print("mhmpcounter3: ");
    print_dec(mhpmcounter3);
    print("\n");
    print("mhmpcounter4: ");
    print_dec(mhpmcounter4);
    print("\n");
    print("mhmpcounter5: ");
    print_dec(mhpmcounter5);
    print("\n");
    print("mhmpcounter6: ");
    print_dec(mhpmcounter6);
    print("\n");
    print("mhmpcounter7: ");
    print_dec(mhpmcounter7);
    print("\n");
    print("mhmpcounter8: ");
    print_dec(mhpmcounter8);
    print("\n");
    print("mhmpcounter9: ");
    print_dec(mhpmcounter9);
    print("\n");*/


    init();

    timeoutcount = 0;

    while(timeoutcount < 20){;}
    

    while(!reset_flag){
        poll_buttons();

        if(timeoutcount >= 12){
            snake_upd();
            timeoutcount = 0;
            if(!snake_check())
                break;
        }
        
    }

    if(!reset_flag){
        print("\nyou lost, score: ");
        print_dec(score);
        print("\n");
        print("current highscore: ");
        print_dec(highscore);
        print("\n");
        if(highscore<score){
            highscore = score;
            print("You got the new highscore! \nNew highscore: ");
            print_dec(highscore);
            print("\n");
        }
        while(!reset_flag)
            poll_buttons();
    }

    print("commence reset \n");

    goto start;
    

    

}








int rand(){
    seed = (seed * 187240) + 94512;
    return (int)(seed & 0x7FFFFFFF);
}